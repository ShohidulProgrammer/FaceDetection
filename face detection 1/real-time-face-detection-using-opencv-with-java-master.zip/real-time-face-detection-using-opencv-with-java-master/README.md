Real time Face Detection using OpenCV with Java (This code is not compatible with opencv 3)


![Alt text](http://s1.postimg.org/g9zf0ks1b/face_detection.jpg "Real Time Face Detection")

**Note:**

to use this code with Opencv 3 see this issue

https://github.com/emara-geek/real-time-face-detection-using-opencv-with-java/issues/1#issuecomment-289291259

See this video to know how to use and develop this code :


http://youtu.be/WeLET1tZPaE


See this video first to know how to install opencv and configure it with netbeans 


https://www.youtube.com/watch?v=BrR6MFhyNEA



My playlist about OpenCV with Java :


https://www.youtube.com/playlist?list=PLONz6FebFXOcKvYs0mm40eWgndxTRBwLc

   
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   Website          :  http://www.emaraic.com 

   Linkedin Profile :  http://eg.linkedin.com/pub/taha-emara/a4/1ab/524/

   E-mail:          :  taha@emaraic.com

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
